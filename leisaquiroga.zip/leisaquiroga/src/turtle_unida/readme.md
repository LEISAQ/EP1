creamos las carpetas con nuestro nombre, y src
luego ejecutamos los paquetes
catkin_create_pkg turtle_unida rospy std_msgs
compilamos los paquetes
abrimos nuestro visual y colo creamos nuestros archivos de mover, editamos el make_list
luego ejecutamos el programa devel.
hacemos run de los archivos .py